/* =========================================================
   NAKHYAD Connect — script.js
   Prototype logic: จำลองการทำงานของ AI Chatbot และฟอร์มแจ้งปัญหา
   ยังไม่เชื่อมต่อ Backend/API จริง (ดูจุดเตรียมเชื่อมต่อด้านล่าง)
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

  /* ---------- 1) เมนูมือถือ (Nav Toggle) ---------- */
  const navToggle = document.getElementById("navToggle");
  const mainNav = document.getElementById("mainNav");

  navToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
  });

  // ปิดเมนูอัตโนมัติเมื่อเลือกลิงก์ (สำหรับหน้าจอมือถือ)
  mainNav.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("open");
      navToggle.setAttribute("aria-expanded", "false");
    });
  });

  /* ---------- 2) Scroll Reveal แบบเรียบง่าย ---------- */
  document.querySelectorAll(
    ".hero-copy, .chatbot-section, .report-section, .services-section, .service-card"
  ).forEach(el => el.classList.add("reveal"));

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));


  /* =========================================================
     3) AI CHATBOT (จำลองด้วย Keyword Matching)
     ---------------------------------------------------------
     ในเวอร์ชันจริง ให้แทนที่ฟังก์ชัน getBotReply() ด้วยการเรียก
     AI API (เช่น Anthropic API) โดยส่งข้อความผู้ใช้ไปประมวลผล
     แล้วรับคำตอบกลับมาแสดงแทน
     ========================================================= */

  const chatBody = document.getElementById("chatBody");
  const chatForm = document.getElementById("chatForm");
  const chatInput = document.getElementById("chatInput");
  const typingIndicator = document.getElementById("typingIndicator");
  const chatStatus = document.getElementById("chatStatus");
  const quickQuestions = document.getElementById("quickQuestions");
  const micBtn = document.getElementById("micBtn");

  // ฐานความรู้จำลอง (Prototype Knowledge Base)
  // TODO: ในระบบจริง เนื้อหานี้ควรดึงจาก Google Sheets หรือฐานข้อมูลของเทศบาล
  const knowledgeBase = [
    {
      keywords: ["ขยะ", "เก็บขยะ", "รถขยะ"],
      reply: "การจัดเก็บขยะแบ่งตามโซนดังนี้ครับ 🚛\n• จันทร์ พุธ ศุกร์ — โซนตลาดและชุมชนใน\n• อังคาร พฤหัสฯ เสาร์ — โซนหมู่บ้านรอบนอก\nกรุณานำขยะออกมาวางก่อนเวลา 07.00 น."
    },
    {
      keywords: ["ภาษี", "ชำระภาษี", "เสียภาษี"],
      reply: "สามารถชำระภาษีที่ดินและสิ่งปลูกสร้าง หรือภาษีป้าย ได้ที่กองคลัง ชั้น 1 สำนักงานเทศบาลตำบลนาขยาด ในวันและเวลาราชการ (จันทร์–ศุกร์ 08.30–16.30 น.)"
    },
    {
      keywords: ["ไฟถนน", "ไฟดับ", "ไฟส่องสว่าง"],
      reply: "หากพบไฟถนนเสียหรือดับ แนะนำให้แจ้งผ่านระบบ “แจ้งปัญหา” ด้านล่างของหน้านี้ พร้อมระบุตำแหน่งให้ชัดเจน เจ้าหน้าที่กองช่างจะดำเนินการซ่อมแซมโดยเร็วครับ"
    },
    {
      keywords: ["ติดต่อ", "เบอร์โทร", "โทรศัพท์"],
      reply: "ติดต่อเทศบาลตำบลนาขยาดได้ที่เบอร์ 0-XXXX-XXXX ในวันจันทร์–ศุกร์ เวลา 08.30–16.30 น. หรือดูรายละเอียดเพิ่มเติมได้ที่ส่วนท้ายของหน้านี้ครับ"
    },
    {
      keywords: ["ถนนชำรุด", "ถนนพัง", "หลุมถนน"],
      reply: "กรณีถนนชำรุดหรือมีหลุมบ่อ กรุณาแจ้งผ่านแบบฟอร์ม “แจ้งปัญหา” พร้อมระบุจุดเกิดเหตุ เพื่อให้เจ้าหน้าที่ลงพื้นที่ตรวจสอบครับ"
    },
    {
      keywords: ["น้ำประปา", "น้ำไม่ไหล", "ประปา"],
      reply: "ปัญหาน้ำประปาสามารถแจ้งผ่านระบบแจ้งปัญหา โดยเลือกประเภท “น้ำประปา” เจ้าหน้าที่การประปาจะติดต่อกลับเพื่อตรวจสอบครับ"
    }
  ];

  const fallbackReply = "ขออภัย ขณะนี้ยังไม่พบข้อมูลสำหรับคำถามนี้ ระบบจะบันทึกคำถามไว้เพื่อให้เจ้าหน้าที่ตรวจสอบ";

  // ค้นหาคำตอบจาก Keyword ในฐานความรู้จำลอง
  function getBotReply(userText) {
    const text = userText.toLowerCase();
    const matched = knowledgeBase.find(item =>
      item.keywords.some(k => text.includes(k))
    );
    return matched ? matched.reply : fallbackReply;
  }

  // เพิ่มข้อความลงในหน้าต่างแชต
  function appendMessage(text, sender) {
    const row = document.createElement("div");
    row.className = `msg-row ${sender}`;

    const avatar = document.createElement("span");
    avatar.className = "msg-avatar";
    avatar.textContent = sender === "bot" ? "🤖" : "🙂";

    const bubble = document.createElement("div");
    bubble.className = `bubble ${sender === "bot" ? "bubble-bot" : "bubble-user"}`;
    bubble.style.whiteSpace = "pre-line";
    bubble.textContent = text;

    row.appendChild(avatar);
    row.appendChild(bubble);
    chatBody.appendChild(row);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  // จำลองสถานะ "AI กำลังพิมพ์..." ก่อนตอบกลับ
  function sendToBot(userText) {
    appendMessage(userText, "user");
    chatInput.value = "";

    typingIndicator.hidden = false;
    chatStatus.textContent = "กำลังพิมพ์...";
    chatBody.scrollTop = chatBody.scrollHeight;

    // หน่วงเวลาจำลองการประมวลผลของ AI
    // TODO: แทนที่ setTimeout นี้ด้วยการเรียก fetch() ไปยัง AI API จริง
    const thinkTime = 700 + Math.random() * 700;
    setTimeout(() => {
      typingIndicator.hidden = true;
      chatStatus.textContent = "พร้อมให้บริการ";
      appendMessage(getBotReply(userText), "bot");
    }, thinkTime);
  }

  chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const value = chatInput.value.trim();
    if (!value) return;
    sendToBot(value);
  });

  // ปุ่มคำถามด่วน
  quickQuestions.querySelectorAll(".chip").forEach(chip => {
    chip.addEventListener("click", () => {
      sendToBot(chip.dataset.q);
      document.getElementById("chatbot").scrollIntoView({ behavior: "smooth", block: "center" });
    });
  });

  /* ---------- ปุ่มไมโครโฟน (Web Speech API หากรองรับ) ---------- */
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = "th-TH";
    recognition.interimResults = false;

    micBtn.addEventListener("click", () => {
      micBtn.classList.add("listening");
      recognition.start();
    });
    recognition.addEventListener("result", (e) => {
      chatInput.value = e.results[0][0].transcript;
    });
    recognition.addEventListener("end", () => micBtn.classList.remove("listening"));
    recognition.addEventListener("error", () => micBtn.classList.remove("listening"));
  } else {
    // เบราว์เซอร์ไม่รองรับการพูด แจ้งเตือนแบบเรียบง่าย
    micBtn.addEventListener("click", () => {
      appendMessage("เบราว์เซอร์นี้ยังไม่รองรับการพิมพ์ด้วยเสียง กรุณาพิมพ์คำถามแทนครับ", "bot");
    });
  }


  /* =========================================================
     4) ระบบแจ้งปัญหา (Report Form)
     ---------------------------------------------------------
     ในระบบจริง ให้ส่งข้อมูลฟอร์มไปยัง Google Sheets (ผ่าน Apps
     Script Web App) หรือฐานข้อมูลของเทศบาล แทนการจำลองด้วย
     ตัวเลขรันนิ่งในเครื่อง
     ========================================================= */

  const reportForm = document.getElementById("reportForm");
  const confirmCard = document.getElementById("confirmCard");
  const reportIdEl = document.getElementById("reportId");
  let reportCounter = 1;

  reportForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const formData = new FormData(reportForm);
    const reportPayload = Object.fromEntries(formData.entries());

    // TODO: แทนที่ด้วยการเรียก fetch() ไปยัง Google Sheets API / Backend จริง
    // fetch("YOUR_GOOGLE_APPS_SCRIPT_URL", {
    //   method: "POST",
    //   body: JSON.stringify(reportPayload)
    // });
    console.log("ข้อมูลแจ้งปัญหา (จำลอง):", reportPayload);

    const idText = `RP${String(reportCounter).padStart(3, "0")}`;
    reportIdEl.textContent = idText;
    reportCounter++;

    confirmCard.hidden = false;
    confirmCard.scrollIntoView({ behavior: "smooth", block: "center" });
    reportForm.reset();
  });

});
